elem = [0,"lolo",2,3,4,5,6]
print("--------------------------------------")
print("numéro : " + str(elem[0]) + ("nom : ").rjust(18) + str(elem[1]))
print("produit" + ("qté").rjust(15) + ("prix").rjust(7) + ("total").rjust(7), end='')
print ("erreur")