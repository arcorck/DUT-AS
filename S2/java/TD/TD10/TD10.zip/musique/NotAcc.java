public interface NotAcc {
    public void jouer ();
}
