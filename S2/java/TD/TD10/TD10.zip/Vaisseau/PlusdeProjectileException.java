public class PlusdeProjectileException extends Exception{
}
