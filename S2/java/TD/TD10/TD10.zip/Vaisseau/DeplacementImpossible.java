public class DeplacementImpossible extends Exception{}
