public class PlusdePointsdeVieException extends Exception{
}
