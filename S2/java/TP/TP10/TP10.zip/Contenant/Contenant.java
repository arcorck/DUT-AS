public interface Contenant<T> {

    public boolean contient (T obj);
}
