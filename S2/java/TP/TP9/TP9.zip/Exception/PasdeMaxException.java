public class PasdeMaxException extends Exception {
}
