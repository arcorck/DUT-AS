public class PasDeTelElementException extends Exception {

}
