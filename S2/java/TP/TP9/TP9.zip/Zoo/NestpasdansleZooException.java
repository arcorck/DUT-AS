public class NestpasdansleZooException extends Exception {
}
