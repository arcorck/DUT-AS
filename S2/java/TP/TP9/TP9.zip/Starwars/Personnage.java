public interface Personnage {
    public String getRace();
    public double getTaille();
    public String getCaracteristique();
    public String getNom();
}
