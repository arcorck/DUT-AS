public class LoueurVehiculesMotorises {

    public void acheter (Motorise m){
        System.out.println("Vous avez achete un véhicule");
    }

    public void commentCaMarche (){
        System.out.println("Ca marche comme ça");
    }
}