public interface Motorise{ 
   public void faireLePlein();
   public void seDeplacer();
}