def inpt () :
    number = input("entrer un chiffre : ")
    if type(number) is int :
        int(number)
        print (3)

inpt()